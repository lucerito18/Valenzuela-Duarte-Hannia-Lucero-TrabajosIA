package Puzzle8;
public class Heuristica {

 public static double distanciaEuclidiana(Nodo n, Nodo objetivo) {
     int dx = n.x - objetivo.x;
     int dy = n.y - objetivo.y;
     return Math.sqrt(dx * dx + dy * dy);
 }
}